message_list = [ u'Circle is 360\u00B0',
               u'Hyv\u00E4\u00E4 \u00FC\u00F6t\u00E4',
               u'\u0989\u09C4 \u09F0 \u09FA \u099F \u09EB \u09EA \u09B9' ]

message1 = message_list[0]
message2 = message_list[1]
message3 = message_list[2]

messages = ', '.join(message_list)

sect = unichr(167)
auml = unichr(228)
ouml = unichr(246)
uuml = unichr(252)
yuml = unichr(255)
