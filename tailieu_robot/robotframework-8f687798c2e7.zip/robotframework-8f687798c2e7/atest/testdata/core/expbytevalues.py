exp_return_value = 'ty\xf6paikka'
exp_return_msg = 'ty\\xf6paikka'
exp_error_msg = 'hyv\\xe4'
exp_log_msg = '\\xe4ity'
