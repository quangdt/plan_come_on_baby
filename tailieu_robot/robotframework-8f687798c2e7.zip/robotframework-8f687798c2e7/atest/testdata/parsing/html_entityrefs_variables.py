scandinavian_letters = u'Hyv\u00E4\u00E4 \u00FC\u00F6t\u00E4 \u00C5\u00C4\u00D6'
xml_escapes = '''& &amp; < <tag> > ' " '" ' &gt;'''
other_escapes = u'\u00A7xxx\u00A7 \u007E \' "'
