public abstract class AbstractJavaLibrary {
}
