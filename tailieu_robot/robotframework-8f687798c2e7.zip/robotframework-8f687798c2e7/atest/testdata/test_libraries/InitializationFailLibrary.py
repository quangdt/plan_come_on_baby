class InitializationFailLibrary:

    def __init__(self):
        raise Exception("Initialization failed!")
