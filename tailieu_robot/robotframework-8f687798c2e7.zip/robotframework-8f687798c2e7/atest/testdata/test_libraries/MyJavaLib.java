public class MyJavaLib {
	
	public String keywordInMyJavaLib(String arg) {
		return "Hi " + arg + "!";
	}
}