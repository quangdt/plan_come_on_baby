def keyword_in_my_lib_file():
    print 'Here we go!!'