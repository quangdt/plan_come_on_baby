#!/bin/bash

pybot --outputdir results --exclude parallel atest/