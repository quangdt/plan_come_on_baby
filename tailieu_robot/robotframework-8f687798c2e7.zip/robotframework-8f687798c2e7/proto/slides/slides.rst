.. include:: <s5defs.txt>
.. include:: <isonum.txt>


===================================
  Introduction to Robot Framework
===================================

.. list-table:: 
   :class: borderless small
   :widths: 60 20

   * - 
       + Generic test automation framework
       + Keyword-driven approach with simple tabular syntax
       + Easy to extend with test libraries implemented using Python or Java
       + Open source under Apache License 2.0
       + Copyrights owned and development supported by Nokia Siemens Networks
       + \http://robotframework.org

     - .. image:: robot.bmp
          :align: right


.. footer:: |copy| Nokia Siemens Networks :: \http://robotframework.org :: Version 0.1



Hello, world!!
==============

Another attemp....

- Spam
- Eggs
- Spam and eggs
- Spam, spam, spam, spam, and eggs


Hiihoo
======

Lorem::

  + item 1
  + item 2
  + item 3


Hi tellus
---------

+ Do something
+ What ever

  - foo
  - bar
