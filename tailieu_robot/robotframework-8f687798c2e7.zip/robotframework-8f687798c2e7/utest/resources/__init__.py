import os

THIS_PATH = os.path.dirname(__file__)
GOLDEN_OUTPUT = os.path.join(THIS_PATH, 'golden_suite', 'output.xml')
GOLDEN_OUTPUT2 = os.path.join(THIS_PATH, 'golden_suite', 'output2.xml')
GOLDEN_JS = os.path.join(THIS_PATH, 'golden_suite', 'expected.js')

