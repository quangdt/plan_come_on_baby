public class ImportByPath {
    public static int attr = 42;
    public static int func() {
        return attr;
    }
}
